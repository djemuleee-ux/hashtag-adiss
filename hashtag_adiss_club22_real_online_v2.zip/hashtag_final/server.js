const express=require('express'),fs=require('fs'),path=require('path'),QRCode=require('qrcode');
const app=express(); const PORT=process.env.PORT||3000; const DB=path.join(__dirname,'data/db.json');
app.use(express.json()); app.use(express.static(path.join(__dirname,'public')));
function read(){return JSON.parse(fs.readFileSync(DB,'utf8'))} function write(d){fs.writeFileSync(DB,JSON.stringify(d,null,2))}
function code(prefix){return prefix+'-'+Date.now().toString(36).toUpperCase()+Math.random().toString(36).slice(2,6).toUpperCase()}
app.get('/health',(req,res)=>res.json({ok:true,service:'HASHTAG ADISS CLUB 22'}));
app.get('/api/data',(req,res)=>res.json(read()));
app.post('/api/bookings',(req,res)=>{const d=read(), b={id:code('TAB'),createdAt:new Date().toISOString(),status:'confirmed',...req.body}; if(!b.name||!b.phone||!b.date||!b.time||!b.table) return res.status(400).json({error:'Missing required fields'}); const clash=d.bookings.find(x=>x.date===b.date&&x.time===b.time&&x.table===b.table&&x.status!=='cancelled'); if(clash)return res.status(409).json({error:'That table is already booked for this time.'}); d.bookings.push(b);write(d);res.json(b)});
app.post('/api/requests',(req,res)=>{const d=read(),r={id:code('SONG'),createdAt:new Date().toISOString(),status:'Pending',...req.body}; if(!r.song||!r.dj)return res.status(400).json({error:'Song and DJ are required'});d.requests.push(r);write(d);res.json(r)});
app.post('/api/birthdays',(req,res)=>{const d=read(),b={id:code('BDAY'),createdAt:new Date().toISOString(),status:'pending',...req.body}; if(!b.name||!b.phone||!b.date)return res.status(400).json({error:'Name, phone and date are required'});d.birthdays.push(b);write(d);res.json(b)});
app.post('/api/tickets',(req,res)=>{const d=read(),t={id:code('TKT'),createdAt:new Date().toISOString(),status:'valid',...req.body};d.tickets.push(t);write(d);res.json(t)});
app.get('/api/qr/:value',async(req,res)=>{try{res.type('png');res.end(await QRCode.toBuffer(req.params.value,{width:420,margin:2}))}catch(e){res.status(500).end()}});
app.get('/admin',(req,res)=>res.sendFile(path.join(__dirname,'public/admin/index.html')));
app.listen(PORT,'0.0.0.0',()=>console.log(`HASHTAG ADISS running on ${PORT}`));
