# HASHTAG ADISS CLUB 22 — Real Online App v2

Mobile-first PWA + Node/Express API for the club. The full club logo is displayed without circular cropping, and the club address is included throughout the app.

## Club information included
- HASHTAG ADISS CLUB 22
- Address: 22 Adisu Asphalt, Addis Ababa, Ethiopia
- Phone: +251 923 090 909 / +251 908 017 123
- Instagram: @hashtag_addiss_club22
- Entry: Adults over 21

## Local run
1. Install Node.js 18+
2. `npm install`
3. `npm start`
4. Open `http://localhost:3000`
5. Manager: `http://localhost:3000/admin`

## Online deployment
The project includes `render.yaml` and binds to `0.0.0.0` so it can be deployed as a Render Web Service. Connect the project to a Git repository, create a Web Service, and use `npm install` / `npm start`.

### Important production note
The current demo stores booking data in `data/db.json`. A production multi-device deployment should replace this with a hosted database such as Supabase/Postgres before accepting real bookings.
